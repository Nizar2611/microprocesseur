#include <xc.h>
#include <stdio.h>
#include "horloge.h"
#include <pic16f877a.h>
//Nizar Oumayma
int mis;
int p=0;
char s = 49;
char m = 02;
char h = 10;
unsigned char r;

unsigned char heure[] = "10:02:49";


void initialise(){
  
    GIE  = 1;                                                                   
    PEIE = 1;  
    TMR1ON = 1;    
    TMR1IE = 1;                                                                 
    T1OSCEN = 1;                                                               
    TMR1CS = 1;                                                              
    T1SYNC = 0;                                                                
    T1CKPS0 = 0;                                                                
    T1CKPS1 = 0;                                                              
    TRISA4 = 1;  
    TRISB = 0X01;
    PORTB = 0X00;
    TRISC2 = 0;
    RC2 = 1;
    CCP1IE = 1;                                                                
    CCP1M3 = 1;                                                                 
    CCP1M2 = 0;
    CCP1M1 = 1;
    CCP1M0 = 0; 
    CCPR1  = 0x8000;               
  
  }
void incrementer(void){
    
if(s < 59){
        s++;
            }else{
                s = 0;
                
                if(m < 59){
                    m++;
                    
                }else{
                    m = 0;
                    
                    if(h < 23){
                        h++;
                    }else{
                        h = 0;
                    }
                }}
}    
void affichetemps(void){
    if((h < 10) && (m < 10) && (s < 10)){
        sprintf(heure, "0%d:0%d:0%d",h,m,s);
    }
    else if((h < 10) && (m< 10)){
        sprintf(heure, "0%d:0%d:%d", h, m,s);
    }
    else if((h < 10) && (s < 10)){
        sprintf(heure, "0%d:%d:0%d", h, m,s);
    }
    else if((m< 10) && (s< 10)){
        sprintf(heure, "%d:0%d:0%d", h, m,s);
    }
    else if(s< 10){
        sprintf(heure, "%d:%d:0%d", h, m,s);
    }
    else if(h < 10){
        sprintf(heure, "0%d:%d:%d", h, m,s);
    }
    else if(m< 10){
        sprintf(heure, "%d:0%d:%d", h, m,s);
    }
    else{
        sprintf(heure, "%d:%d:%d", h, m,s);
    }
}


void interrupt isr( void ){
    
    if ( (TMR1IF == 1  )||(CCP1IF==1)){                                                            
        
        RB1=~RB1;
        TMR1IF = 0;
        CCP1IF=0;
        incrementer();
        mis = 1;
        p++;
             
          
    }
  }


int appuis2(){
    int valinit=p;
    int valact=p;

    if(S2 == 0){
        while((S2 == 0) && ((valact - valinit) < 2)){
            valact=p;
        }
        if((valact - valinit) >= 2){
            return 0;                                                          
        }else{
            return 1;                                                           
        }
    }else{
        return 2;                                                              
    }
}


int appuis3(){
    int valinit=p;
    int valact=p;

    if(S3 == 0){
        while((S3 == 0) && ((valact - valinit) < 2)){
            valact=p;
        }
        if((valact - valinit) >= 2){
            return 0;                                                          
        }else{
            return 1;                                                           
        }
    }else{
        return 2;                                                              
    }
}



void activer_clignot(void){
    lcd_write_instr(0b00001101);                                      
}

void desactiver_clignot(void){                                                
    lcd_write_instr(0b00001100);
}

void clignoter_heures(void){
    lcd_home();
    lcd_write_instr(0b00010100);  
    
}

void clignoterminutes(void){
    lcd_home();
    for(int i = 0; i<4; i++){
        lcd_write_instr(0b00010100);  
    }
        
}


void capteur_temp_init()
{
	TRISC3 = 1;
	TRISC4 = 1;
	SSPBUF = 0x00;
	SSPSTAT = 0xc0;
	SSPCON = 0x28;
	SSPCON2 = 0x00;
	SSPIF = 0;
	SSPADD = 0x09;
}
void capteur_temp_debut()
{
	SEN = 1;
	while(SEN);
}

void pause_capteur()
{
	while(SSPIF==0);
	SSPIF = 0;
}

void suite_capteur()
{
	RSEN = 1;
	while(RSEN);
}

void capteu_nack()
{
	ACKDT = 1;
	ACKEN = 1;
	while(ACKEN);
}

void i2c_stop()
{
	pause_capteur();
	PEN = 1;
	while(PEN);
}

unsigned char i2c_rx()
{
	RCEN = 1;
	while(!BF);
	return SSPBUF;
}

unsigned char capteur_send(unsigned char c)
{
	SSPBUF = c;
	while(BF);
	pause_capteur();
}

void affichetemperature ( unsigned char temp ){
    lcd_pos(0b00000010,0b00000001);	
    unsigned char signe;
    if ( temp > 128 ){
            temp = 256 - temp;
            signe = 1;
        }
        else {
            signe = 0;
        }
        if ( signe == 1 ){
            lcd_putch( '-' );
        }
        else{
            if (!( temp / 100 )){
                lcd_putch(' ');
            }
            else{
                lcd_putch( temp/100 + '0' );
            }
        }
        lcd_putch( temp/10 + '0' );
        lcd_putch( temp%10 + '0' );
        lcd_putch(223);
        lcd_puts("[C] ");
}


void temperature ( void ) {
		lcd_pos(0b00000010,0b00000001);		
		capteur_temp_debut();	
		__delay_ms(4);

		capteur_send(0x9A);  

		suite_capteur(); 
		__delay_ms(4);

		SSPBUF = 0x9B; 
		pause_capteur();
		__delay_ms(4);

		r = i2c_rx(); 
		pause_capteur();

		capteu_nack(); 
		__delay_ms(4);

		i2c_stop(); 
		__delay_ms(4);
        affichetemperature( r );
}


void main(){
    initialise();
    lcd_init();
    capteur_temp_init();
    
     while(1){
         
          
       
         RB2=~RB2;
         if ( mis == 1 ){
             mis = 0;
             lcd_home();
             lcd_puts(heure);
             affichetemps();
         }
         else if(appuis2()==0){
          activer_clignot();                                                     
            clignoter_heures(); 
            
        while(appuis2() != 2){  
            temperature();
            lcd_home();
            }
        while(appuis2() == 2){ 
            temperature();
                if(appuis3() == 0){                                            
                    while(S3 == 0){                                             
                        if(h < 23){                                         
                            h++;
                        }else{
                            h = 0;
                        }
                        affichetemps();                                          
                        lcd_clear();
                        lcd_puts(heure);
                        lcd_home();
                        clignoter_heures();
                        __delay_us(250);
                    }  
                }else if(appuis3() == 1){                                      
                    if(h < 23){                                             
                        h++;
                    }else{
                        h = 0;
                    }
                    affichetemps();                                          
                    lcd_clear();
                    lcd_puts(heure);
                    lcd_home();
                    clignoter_heures();}}
                clignoterminutes();
                while(appuis2() !=2){                                          
                
            }
            while(appuis2() ==2){ 
                temperature();
                if(appuis3() == 0){                                           
                    while(S3 == 0){                                           
                        if(m < 59){                                   
                            m++;
                        }else{
                            m= 0;
                            }
                        affichetemps();                                         
                        lcd_clear();
                        lcd_puts(heure);
                        lcd_home();
                        clignoterminutes();
                        __delay_us(250);
                    }  
                }else if(appuis3() == 1){                                
                    if(m < 59){                                           
                        m++;
                    }else{
                        m= 0;
                        
                    }   
                    affichetemps();                                                  
                    lcd_clear();
                    lcd_puts(heure);
                    lcd_home();
                    clignoterminutes();
                     
                }
            }
            
        }
            
         desactiver_clignot();
         //temperature();
        
             
    }
    
}


