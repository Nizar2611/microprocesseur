#include "lib_LCD.h"
#include <xc.h>
#include <pic16f877a.h>

//******************************************************************
// Initialisation g�n�rale de l'afficheur en mode 4 bits
//******************************************************************


// Nizar Oumayma
void lcd_init() {
    TRISD = 0; 
    E = 0;
    VCC = 1;
  __delay_ms(20);
    RS = 0;
    RW = 0;
    E = 1;
    DB4 = 1;
    DB5 = 1;
    DB7 = 0;
    DB6 = 0;
    E = 0;
    __delay_ms(4.5);
    E = 1;
    DB4 = 1;
    DB5 = 1;
    DB7 = 0;
    DB6 = 0;
    
    E = 0;
    __delay_us(110);
    E = 1;
    DB4 = 1;
    DB5 = 1;
    DB7 = 0;
    DB6 = 0;
    E = 0;
    __delay_us(40);
    E = 1;
    DB4 = 0;
    DB5 = 1;
    DB7 = 0;
    DB6 = 0;
    E = 0;

    __delay_us(40);
    lcd_write_instr(0b00101000);
    lcd_write_instr(0b00001000);
    lcd_write_instr(0b00000001);
    lcd_write_instr(0b00000110);
    lcd_write_instr(0b00001100);
   
}

void lcd_busy(){
    __delay_ms(43);
}



//******************************************************************
// Envoi d'une instruction vers le module LCD
//******************************************************************
void lcd_write_instr(unsigned char c) {
    RS = 0;
    RW = 0;
    
    E = 1;
    
    DB7 = (c & 0b10000000)>>7;
    DB6 = (c & 0b01000000)>>6;
    DB5 = (c & 0b00100000)>>5;
    DB4 = (c & 0b00010000)>>4;
    
    E = 0;
    __delay_us(41);
    E = 1;
        
    
    RS = 0;
    RW = 0;
    DB7 = (c & 0b00001000)>>3;
    DB6 = (c & 0b00000100)>>2;
    DB5 = (c & 0b00000010)>>1;
    DB4 =  c & 0b00000001;
    
    E = 0;
    lcd_busy();
 }
    


//******************************************************************
// Ecriture d'un caract�re sur l'afficheur
//******************************************************************
void lcd_putch(unsigned char c) {
    RS = 1;
    RW = 0;
    
    E = 1;
    
    DB7 = (c & 0b10000000)>>7;
    DB6 = (c & 0b01000000)>>6;
    DB5 = (c & 0b00100000)>>5;
    DB4 = (c & 0b00010000)>>4;
    
    E = 0;
    __delay_us(41);
    E = 1;
        
    
    RS = 1;
    RW = 0; 
    DB7 = (c & 0b00001000)>>3;
    DB6 = (c & 0b00000100)>>2;
    DB5 = (c & 0b00000010)>>1;
    DB4 =  c & 0b00000001;
    
    E = 0;
    lcd_busy();
    
}

//******************************************************************
// Ecriture d'une chaine de caract�res sur l'afficheur
//******************************************************************
void lcd_puts(const unsigned char *s) {
    int i;
    while(*s!='\0') 
{
  lcd_putch(*s); 
  s++;
}
  lcd_busy();  
}

//******************************************************************
// Positionnement du curseur en (x,y) - origine en (1,1)
//******************************************************************
void lcd_pos(unsigned char ligne, unsigned char pos) {
    if(ligne==1){
        lcd_write_instr(pos+0x80-1);
        }
    if(ligne==2){
        lcd_write_instr(0xC0+pos-1);
    }
    
}

//******************************************************************
// Effacement de l'ecran et cursor home
//******************************************************************
void lcd_clear() {
    lcd_write_instr(0b00000001);
    __delay_ms(1.7);
    lcd_home();
}

//******************************************************************
// Cursor home
//******************************************************************
void lcd_home() {
    lcd_write_instr(0b00000010);
    __delay_ms(1.7);
}